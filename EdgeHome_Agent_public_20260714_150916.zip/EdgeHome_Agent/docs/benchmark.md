# EdgeHome 基准说明

运行 python scripts/benchmark_edgehome.py --iterations 1000 可以获得固定计划 Pydantic 校验的本地耗时和 Python 峰值内存。它不调用模型、不调用 Home Assistant 服务，也不把结果冒充为端到端推理性能。

在目标设备上还应记录 llama.cpp 模型名称、GGUF 量化级别、上下文长度、CPU/GPU 设置、并发数，以及典型复杂任务的端到端时间。EdgeHome 的 ResourceMonitor 会记录复杂规划的 CPU 时间、峰值内存增量、耗时和起始并发数，但不记录用户输入或密钥。

第 12 阶段的真实本地测量结果（索引构建、检索、CSV 装载、分析、异常检测）记录在 `reports/PHASE12_PERFORMANCE_REPORT.md`。确定性分析没有模型解释调用；若后续启用模型转写，必须单独记录其耗时，不能混入算法时间。

第 13 阶段的真实模型、双路径、并发、断网和稳定性原始结果位于 `benchmark/results/`，汇总见 `reports/`。同一模型的不同上下文是推理配置对比，不能表述为不同量化模型；非流式调用无法采集 TTFT 时必须保持 `null`。
