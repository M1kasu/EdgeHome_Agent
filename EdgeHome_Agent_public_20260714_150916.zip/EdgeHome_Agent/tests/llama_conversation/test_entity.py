"""Tests for LocalLLMClient helpers in entity.py."""

import inspect
import json
import pytest

from custom_components.llama_conversation.entity import LocalLLMClient
from custom_components.llama_conversation.const import (
    CONF_EXTRA_ATTRIBUTES_TO_EXPOSE,
    CONF_USE_IN_CONTEXT_LEARNING_EXAMPLES,
    DEFAULT_TOOL_CALL_PREFIX,
    DEFAULT_TOOL_CALL_SUFFIX,
    DEFAULT_THINKING_PREFIX,
    DEFAULT_THINKING_SUFFIX,
)
from custom_components.llama_conversation.utils import (
    MalformedToolCallException,
    parse_raw_tool_call,
    parse_tool_arguments_with_repair_fallback,
)


class DummyLocalClient(LocalLLMClient):
    @staticmethod
    def get_name(_client_options):
        return "dummy"


class DummyLLMApi:
    def __init__(self):
        self.tools = []


@pytest.fixture
def client(hass):
    # Disable ICL loading during tests to avoid filesystem access.
    return DummyLocalClient(hass, {CONF_USE_IN_CONTEXT_LEARNING_EXAMPLES: False})


def test_parse_raw_tool_call_rejects_non_object_arguments():
    raw_tool = '{"name":"light.turn_on","arguments":[]}'

    with pytest.raises(MalformedToolCallException):
        parse_raw_tool_call(raw_tool, "agent-id")


def test_parse_tool_arguments_with_repair_fallback_rejects_non_object_json():
    with pytest.raises(MalformedToolCallException):
        parse_tool_arguments_with_repair_fallback("[]", "agent-id", "light.turn_on")


@pytest.mark.asyncio
async def test_async_stream_parse_completion_handles_streamed_tool_call(client):
    async def token_generator():
        yield ("Hi", None)
        yield (
            None,
            [
                {
                    "function": {
                        "name": "light.turn_on",
                        "arguments": {"brightness": 0.25, "to_say": " ok"},
                    }
                }
            ],
        )

    stream = client._async_stream_parse_completion(
        DummyLLMApi(), "agent-id", {}, anext_token=token_generator()
    )

    results = [chunk async for chunk in stream]

    assert results[0].response == "Hi"
    assert results[1].response.strip() == "ok"
    assert results[1].tool_calls[0].tool_args["brightness"] == 63


@pytest.mark.asyncio
async def test_async_stream_parse_completion_malformed_tool_raises(client):
    async def token_generator():
        yield ("Hi", None)
        yield (None, ["{not-json"])

    with pytest.raises(MalformedToolCallException):
        async for _chunk in client._async_stream_parse_completion(
            DummyLLMApi(), "agent-id", {}, anext_token=token_generator()
        ):
            pass


@pytest.mark.asyncio
async def test_async_stream_parse_completion_ignores_tools_without_llm_api(client):
    async def token_generator():
        yield ("Hi", None)
        yield (None, ["{}"])

    results = [chunk async for chunk in client._async_stream_parse_completion(
        None, "agent-id", {}, anext_token=token_generator()
    )]

    assert results[0].response == "Hi"
    assert results[1].tool_calls is None


@pytest.mark.asyncio
async def test_async_get_exposed_entities_respects_exposure(monkeypatch, client, hass):
    hass.states.async_set("light.exposed", "on", {"friendly_name": "Lamp"})
    hass.states.async_set("switch.hidden", "off", {"friendly_name": "Hidden"})

    monkeypatch.setattr(
        "custom_components.llama_conversation.entity.async_should_expose",
        lambda _hass, _domain, entity_id: not entity_id.endswith("hidden"),
    )

    exposed = client._async_get_exposed_entities()

    assert "light.exposed" in exposed
    assert "switch.hidden" not in exposed
    assert exposed["light.exposed"]["friendly_name"] == "Lamp"
    assert exposed["light.exposed"]["state"] == "on"


@pytest.mark.asyncio
async def test_generate_system_prompt_renders(monkeypatch, client, hass):
    hass.states.async_set("light.kitchen", "on", {"friendly_name": "Kitchen"})
    monkeypatch.setattr(
        "custom_components.llama_conversation.entity.async_should_expose",
        lambda _hass, _domain, _entity_id: True,
    )

    rendered = client._generate_system_prompt(
        "Devices:\n{{ formatted_devices }}",
        llm_api=None,
        entity_options={CONF_EXTRA_ATTRIBUTES_TO_EXPOSE: []},
    )
    if inspect.iscoroutine(rendered):
        rendered = await rendered

    assert isinstance(rendered, str)
    assert "light.kitchen" in rendered
